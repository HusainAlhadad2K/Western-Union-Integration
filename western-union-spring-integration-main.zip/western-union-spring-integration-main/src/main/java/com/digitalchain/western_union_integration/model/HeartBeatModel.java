package com.digitalchain.western_union_integration.model;

/**
 * Define the models for the request and response for the REST API
 * **/
public class HeartBeatModel {
}

package com.digitalchain.western_union_integration.controller;

import com.digitalchain.western_union_integration.service.HeartBeatService;
import com.integration.template.adapters.OpenAPIAdapter.annotation.RateLimited;
import com.integration.template.adapters.OpenAPIAdapter.annotation.Throttled;
import com.integration.template.adapters.OpenAPIAdapter.exception.RateLimitExceededException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * Define REST API routes here that execute the code in the service package, using the open api adapter
 **/

@RestController
@RequestMapping("/api/v1/heartbeat/")
public class HeartBeatController {
    @Autowired
    private final HeartBeatService heartBeatService;

    public HeartBeatController(HeartBeatService heartBeatService) {
        this.heartBeatService = heartBeatService;
    }

    @GetMapping("/")
    public String mock(){
        return heartBeatService.getMock();
    }
}

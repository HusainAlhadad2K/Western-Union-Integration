package com.digitalchain.western_union_integration.service;

import org.springframework.stereotype.Service;

/**
 * Define services here than execute the routes in controller package
 **/

@Service
public class HeartBeatService {

    public String getMock() {
        return "mock";
    }
}

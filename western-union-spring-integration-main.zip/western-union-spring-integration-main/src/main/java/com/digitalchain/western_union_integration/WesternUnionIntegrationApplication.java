package com.digitalchain.western_union_integration;

import com.integration.template.adapters.rest_adapter.service.RestAdapter;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import java.util.Map;

@SpringBootApplication
public class WesternUnionIntegrationApplication {

    public static void main(String[] args) {
        SpringApplication.run(WesternUnionIntegrationApplication.class, args);
    }

}
